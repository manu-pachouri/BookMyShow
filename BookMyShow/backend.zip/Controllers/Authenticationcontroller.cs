﻿using backend.Models;
using backend.Models.Authentication;
using backend.Models.ViewModels;
using backend.Services.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace backend.Controllers
{
    [Route("authentication")]
    [ApiController]
    public class Authenticationcontroller : ControllerBase
    {
        public Authenticationcontroller(AuthenticationService authService)
        {
            this._authService = authService;
        }
        private AuthenticationService _authService { get; }

        [HttpPost]
        [Route("login")]
        public async Task<TokenViewModel> Login([FromBody] LoginViewModel model)
        {
            TokenViewModel Token = await this._authService.LoginAsync(model);
            return Token;
        }

        [HttpPost]
        [Route("register")]
        public async Task<bool> Register([FromBody] RegisterViewModel model)
        {
            var result = await this._authService.RegisterAsync(model);
            return result;
        }

        [HttpPost]
        [Route("logout")]
        public async Task Logout()
        {
            await this._authService.LogoutAsync();
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        [Route("adminpanel/users")]
        public List<IdentityUser> GetUsers()
        {
            return this._authService.GetUSers();
        }

        [HttpDelete]
        [Authorize(Roles = "Admin")]
        [Route("adminpanel/users/delete/{userName}")]
        public async Task DeleteUser(string userName)
        {
            await this._authService.DeleteUserAsync(userName);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [Route("adminpanel/users/changepass")]
        public async Task ChangeUserPassword([FromBody] PassChangeModel model)
        {
            await this._authService.ChangePassAsync(model);
        }
    }
}
