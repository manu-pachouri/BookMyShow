﻿using backend.Models;
using backend.Services.Authentication;
using backend.Services.AppService;
using SimpleInjector;
using Microsoft.EntityFrameworkCore;
using BMSIntegrated.AutoMapper;

namespace backend
{
    public static class RegisterServices
    {
        public static void Register(Container container)
        {
            container.Register<AuthenticationService>(Lifestyle.Scoped);
            container.Register<MapperProvider>();
            container.Register<IAppService, AppService>(Lifestyle.Singleton);
            container.Register<DbContext, BMSContext>(Lifestyle.Scoped);

            container.RegisterSingleton(() => GetMapper(container));
        }

        private static AutoMapper.IMapper GetMapper(Container container)
        {
            var mp = container.GetInstance<MapperProvider>();
            return mp.GetMapper();
        }
    }
}
